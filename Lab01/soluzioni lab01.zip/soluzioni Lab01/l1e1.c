// Nota: la funzione che calcola il risultato a partire dagli operandi (operazione)
// riceve, oltre agli operandi, il codice del'operazione.
// Si accettano altre soluzioni, che ad esempio prevedano 4 funzioni distinte
// (per le 4 operazioni)
// l'input viene fatto utilizzando esclusivamente formati %s per semplificare 
// la gestione del formato e del carattere a-capo. 
// L'uso di un %c per il codice del'operazione richiederebbe lettura esplicita 
// del carattere a-capo.


#include<stdlib.h>
#include<stdio.h>

float operando(char s[], float precedente) {
  if (strcmp(s, "PREV") == 0)
    return precedente;
  return atof(s);
}

int valido (char op) {
  switch(op) {
    case '+':
    case '-':
	case '*':
	case '/':
	  return 1;
      break;
    default:
      return 0;
    break;
  }
}

float operazione(char op, float opd1, float opd2) {
  switch(op) {
	case '+':
	  return opd1+opd2;
      break;
	case '-':
	  return opd1-opd2;
      break;
	case '*':
	  return opd1*opd2;
      break;
	case '/':
	  return opd1/opd2;
      break;
    default:
      printf("Errore\n"); // messo unicamente per debug
      return 0.0;
    break;
  }
}

int main(void) {

  char opd1[6], opd2[6], op;
  float n1, n2, ris = 0.0;
  int cicla = 1;

  while(cicla) {
    printf("Nuova operazione: ");
    fscanf(stdin," %c", &op); // cerca primo carattere non spazio/a-capo
	cicla = valido(op);
	if (cicla) {
      fscanf(stdin,"%s %s", opd1, opd2); 
      n1 = operando(opd1, ris);
	  n2 = operando(opd2, ris);
      ris = operazione(op,n1, n2);
      printf("Risultato: %f\n", ris);
    }
  }
  return 0;
}
