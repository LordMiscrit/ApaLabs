#include<stdlib.h>
#include<stdio.h>

#define DIM 20
#define MAX_NAME 11

void stampaCornice(int m[DIM][DIM], int n, int c) {
  int dim = n - c*2, i;
  if (dim  <= 0)
    return;
  for (i=0; i<dim; i++)
    printf("%d ", m[c][c+i]);
  for (i=0; i<dim-1; i++)
    printf("%d ", m[c+i+1][n-c-1]);
  for (i=0; i<dim-1; i++)
    printf("%d ", m[n-c-1][n-c-i-2]);
  for (i=0; i<dim-2; i++)
    printf("%d ", m[n-c-i-2][c]);
}

void stampa(int m[DIM][DIM], int n) {
  int i, j;
  for (i=0; i<n; i++) {
    for (j=0; j<n; j++)
      fprintf(stdout, "%d ", m[i][j]);
    printf("\n");
  }
  return;
}

int main(void) {
  int matrice[DIM][DIM];
  int i, j, n;
  char f[MAX_NAME];
  FILE *fin = NULL;

  printf("Inserisci il nome del file di input\n");
  fscanf(stdin, "%s", f);
  fin = fopen(f,"r");
  if (fin==NULL){
    printf("Errore durante l'apertura del file %s", f);
    return -1;
  }

  fscanf(fin, "%d\n", &n);
  for (i=0; i<n; i++) {
    for (j=0; j<n; j++)
      fscanf(fin, "%d", &matrice[i][j]);
  }

  stampa(matrice, n);

  int nCornici = n/2 ;
  for (i=0; i<nCornici; i++)
    stampaCornice(matrice, n, i);
  if (n % 2)
    printf("%d\n", matrice[n/2][n/2]);
  else printf("\n");
  return 0;
}
