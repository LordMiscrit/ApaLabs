// NOTA: la funzione valutaHorner potrebbe essere modificata 
// aggiungendo come ulteriore parametro il grado
// Si presenta tuttavia la soluzione che esamina sempre tutti i coefficienti

#include<stdlib.h>
#include<stdio.h>

#define MAX_DEG 10

float valutaHorner(int P[MAX_DEG+1], float x) {
  int i;
  float p = 0;
  for (i=MAX_DEG; i>=0; i--)
    p = p*x + P[i];
  return p;
}

int main(void) {

  int grado, a, b, M, i, coeff[MAX_DEG+1] = {0};
  float mid, I = 0.0;
  float h = 0.0;

  printf("Inserire grado del polinomio: ");
  scanf("%d", &grado);
  if (grado > MAX_DEG){
    printf("Errore: grado troppo grande");
    return -1;
  }
  for(i=grado; i>=0; i++) {
    printf("Coefficiente del termine di grado %d: ", i);
	scanf("%d", &coeff[i]);
  }

  printf("Inserire estremo a: ");
  scanf("%d", &a);
  printf("Inserire estremo b: ");
  scanf("%d", &b);
  if (a > b){
    printf("Errore: estremi di integrazione incompatibili");
    return -1;
  }
  printf("Inserire numero di intervalli: ");
  scanf("%d", &M);
  if (M <= 0){
    printf("Errore: numero di intervalli non corretto");
    return -1;
  }

  h = (b-a)/(float)M;
  mid = a + h/(float)2;

  for (i=0; i<M; i++) {
    I += valutaHorner(coeff, mid);
	mid += h;
  }
  printf("I = %f\n", I*h);
  return 0;
}
