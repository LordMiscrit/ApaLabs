#include <stdio.h>
#include <stdlib.h>

#define DIM      20
#define FILE_IN  "l2e1.txt"
#define FILE_OUT "l2e1.out.txt"

void ruotaVettore(int V[], int dir, int N, int P);
void ruotaMatrice(int mat[][DIM], char r_o_c, int target, int dim1, int dim2, int P, int dir);
void leggiMatrice(char *file, int mat[][DIM], int *nr, int *nc);
void stampaMatrice(FILE *out, int mat[][DIM], int nr, int nc);

int main(void) {
  int dim1, dim2, mat[DIM][DIM], continua = 1, target, pos, dir;
  char cmd[256], selettore[20], r_o_c;
  leggiMatrice(FILE_IN, mat, &dim1, &dim2);
  do {
	stampaMatrice(stdout, mat, dim1, dim2);
	printf("Comando > ");
	fgets(cmd, 255, stdin);
	sscanf(cmd, "%s %d %d %d", selettore, &target, &pos, &dir);

	if (strcmp(selettore,"riga")==0) {
      if (target <= 0 || target > dim1) {
        printf("Errore selezione riga\n");
        return 1;
      }
      r_o_c = 'r';
      ruotaMatrice(mat, r_o_c, target, dim1, dim2, pos, dir);
   } else if (strcmp(selettore,"colonna")==0) {
      if (target <= 0 || target > dim2) {
        printf("Errore selezione colonna\n");
        return 1;
      }
      r_o_c = 'c';
      ruotaMatrice(mat, r_o_c, target, dim1, dim2, pos, dir);
   } else if (strcmp(selettore,"fine")==0) {
      continua=0;
   } else {
      printf("riga|colonna|fine [target] [pos] [dir]\n");
   }
  } while (continua);
  return 0;
}

void ruotaMatrice(int mat[][DIM], char r_o_c, int target, int dim1, int dim2, int P, int dir) {
  int vet[DIM], i;
  if (r_o_c == 'r')
    ruotaVettore(mat[target-1], dir, dim2, P);
   else if (r_o_c == 'c') {
     for (i=0; i<dim1; i++)
       vet[i] = mat[i][target-1];
     ruotaVettore(vet, !dir, dim1, P);
     for (i=0; i<dim1; i++)
       mat[i][target-1] = vet[i];
   }
}

void ruotaVettore(int V[], int dir, int N, int P) {
  int tmp, i, j;

  if (P <= 0)
    return;
  P = P%N; // serve per il caso di P>N

  if (dir == 0) { // SX
	for (i=0; i<P; i++) {
      tmp = V[0];
	  for (j=0; j<N-1; j++)
        V[j] = V[(j+1)];
      V[N-1] = tmp;
    }
  } else {  // DX
   	for(i=0; i<P; i++) {
      tmp = V[N-1];
	  for(j=N-1; j>0; j--)
        V[j] = V[j-1];
      V[0] = tmp;
	}
  }
}

void ruotaVettore2(int V[], int dir, int N, int P) {
  int tmpVet[DIM], i;

  if (P <= 0)
    return;
  P = P%N; // serve per il caso di P>N

  if (dir == 0) { // SX
    // salva parte iniziale di tmpVet
	for (i=0; i<P; i++) {
      tmpVet[i] = V[i];
	}
	// sposta di P posizioni a destra
	for (i=0; i<N-P; i++) {
      V[i] = V[i+P];
    }
    // copia dati salvati in tmpVet
	for (i=0; i<P; i++) {
      V[N-P-1+i] = tmpVet[i];
	}
  } else {  // DX
    // parte duale per spostamento a destra
	for (i=0; i<P; i++) {
      tmpVet[i] = V[N-P-1+i];
	}
	for (i=N-1; i>=P; i--) {
      V[i] = V[i-P];
    }
	for (i=0; i<P; i++) {
      V[i] = tmpVet[i];
	}
  }
}

void leggiMatrice(char *file, int mat[][DIM], int *nr, int *nc) {
  int i, j;
  FILE *in = fopen(file, "r");
  if (in == NULL)
    exit(-1);
  fscanf(in, "%d %d", nr, nc);
  for(i=0; i<*nr; i++)
    for(j=0;j<*nc;j++)
	  fscanf(in, "%d", &mat[i][j]);
  fclose(in);
  return;
}

void stampaMatrice(FILE *out, int mat[][DIM], int nr, int nc) {
  int i, j;
  for (i=0; i<nr; i++) {
    for(j=0; j<nc; j++)
      fprintf(out, "%d ", mat[i][j]);
	fprintf(out, "\n");
  }
  fprintf(out, "\n");
  return;
}
