#include <stdio.h>
#include <stdlib.h>

#define N        20
#define FILE_IN  "l2e3.txt"
#define FILE_OUT "l2e3.out.txt"


void leggiMatrice(FILE *in, int mat[][N], int nr, int nc);
void stampaMatrice(FILE *out, int mat[][N], int nr, int nc);
void risolvi1(int mat[][N], int r, int nr, int nc); // per cornici, con for
void risolvi2(int mat[][N], int r, int nr, int nc); // per cornici, con while
void risolvi3(int mat[][N], int r, int nr, int nc); // for annidati saltando celle fuori raggio


int main(void) {
  int nr, nc, mat[N][N], r;
  FILE *in = fopen(FILE_IN, "r");
  if (in == NULL)
    exit(-1);
  // leggi dimensioni da prima riga
  fscanf(in, "%d %d", &nr, &nc);
  leggiMatrice(in, mat, nr, nc);
  fclose(in);
  printf("Inserisci raggio: ");
  scanf("%d", &r);
  risolvi1(mat, r, nr, nc);
  return 0;
}

void leggiMatrice(FILE *fin, int mat[][N], int nr, int nc) {
  int i, j;
  for (i=0; i<nr; i++) {
    for (j=0; j<nc; j++)
	  fscanf(fin, "%d", &mat[i][j]);
  }
  return;
}

void stampaMatrice(FILE *out, int mat[][N], int nr, int nc) {
  int i, j;
  for (i=0; i<nr; i++) {
    for(j=0;j<nc;j++)
      fprintf(out, "%d ", mat[i][j]);
    fprintf(out, "\n");
  }
  return;
}

void risolvi1(int mat[][N], int r, int nr, int nc) {
  FILE *out = fopen(FILE_OUT, "w");
  int somma, i, j, x, y;
  for (i=0; i<nr; i++) {
    for (j=0; j<nc; j++) {
      somma = 0;
	  for (x = i-r, y = j-r; y <=j+r; y++)
		if(x>=0 && x<nr && y>=0 && y<nc)
          somma += mat[x][y];
      for (x = i-r+1, y = j+r; x<= i+r; x++)
        if(x>=0 && x<nr && y>=0 && y<nc)
          somma += mat[x][y];
      for (x = i+r, y=j-r; y< j+r; y++)
        if(x>=0 && x<nr && y>=0 && y<nc)
          somma += mat[x][y];
      for (x = i-r+1, y = j-r; x< i+r ; x++)
        if(x>=0 && x<nr && y>=0 && y<nc)
          somma += mat[x][y];
      fprintf(out, "%d ", somma);
    }
    fprintf(out, "\n");
  }
  fclose(out);
}

void risolvi2(int mat[][N], int r, int nr, int nc) {
  FILE *out = fopen(FILE_OUT, "w");
  int somma, i, j, x, y;
  for (i=0; i<nr; i++) {
    for(j=0; j<nc; j++) {
	  somma = 0;
	  x = i - r;
	  if (x >= 0)  {
        y = j - r;
		if (y<0)
          y = 0;
		while (y<nc && y <=(j+r)) {
          somma += mat[x][y];
		  y++;
		}
      }

	  y = j + r;
	  if (y < nc) {
        x = i - r +1;
		if (x < 0)
          x = 0;
        while (x<nr && x <=(i+r)) {
          somma += mat[x][y];
		  x++;
        }
      }

	  x = i + r;
	  if (x<nr) {
        y = j - r;
		if (y<0)
          y = 0;
        while (y<nc && y <=(j+r-1)) {
		  somma += mat[x][y];
		  y++;
        }
      }

	  y = j - r;
      if (y >= 0) {
        x = i - r +1;
        if (x<0)
          x = 0;
        while(x<nr && x <=(i+r-1)) {
          somma += mat[x][y];
          x++;
        }
      }
	  fprintf(out, "%d ", somma);
    }
	fprintf(out, "\n");
  }
  fclose(out);
}

void risolvi3(int mat[][N], int r, int nr, int nc) {
  FILE *out = fopen(FILE_OUT, "w");
  int somma, i, j, x, y, sx, sy;
  for (i=0; i<nr; i++) {
    for(j=0; j<nc; j++) {
	  somma = 0;
      for(x=-r; x<=r; x++) {
        for (y=-r; y<=r; y++) {
          sx = i+x;
          sy = j+y;
		  if (sx>=0 && sx<nr && sy>=0 && sy<nc
              && (abs(x)==r || abs(y)== r))
            somma += mat[sx][sy];
        }
      }
      fprintf(out, "%d ", somma);
    }
    fprintf(out, "\n");
  }
  fclose(out);
}


