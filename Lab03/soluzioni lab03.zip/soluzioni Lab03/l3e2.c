#include<stdlib.h>
#include<stdio.h>

#define MAXR    1000
#define STR     31
#define CMD   5
#define FILE_IN "accessi.txt"

typedef struct {
  int a;
  int m;
  int g;
} data_t;

typedef struct {
  char ip[STR];
  char user[STR];
  char time[STR];
  char tipo[STR];
  char risorsa[STR];
  char risposta[STR];
  data_t data;
} entry_t;

typedef enum {r_nome, r_ip, r_rifiuto, r_risorsa, r_fine} comando_e;

int leggiTabella(entry_t *log);
int confrontaDate(data_t d1, data_t d2);
comando_e leggiComando(char comandi[][STR]);
void stampaComandi(char comandi[][STR]);
void selezionaDati(entry_t *log, int nr, comando_e cmd);

int main(void) {
  entry_t log[MAXR];
  char comandi[][STR] = {"nome", "IP", "rifiuto", "risorsa", "fine"};
  int nr, continua = 1;
  comando_e cmd;

  nr = leggiTabella(log);
  stampaComandi(comandi);
  do {
        cmd = leggiComando(comandi);
		switch(cmd) {
			case r_nome:
                selezionaDati(log, nr, r_nome);
				break;
			case r_ip:
                selezionaDati(log, nr, r_ip);
				break;
			case r_rifiuto:
                selezionaDati(log, nr, r_rifiuto);
				break;
			case r_risorsa:
                selezionaDati(log, nr, r_risorsa);
				break;
			case r_fine:
				continua = 0;
				break;
            default:  stampaComandi(comandi);
		}
	} while(continua);
	return 0;
}


int confrontaDate(data_t d1, data_t d2) {
  if (d1.a != d2.a) 
    return (d1.a-d2.a);
  else if (d1.m != d2.m) 
    return (d1.m-d2.m);
  else if (d1.g != d2.g) 
    return (d1.g-d2.g);
  else return 0;
}

int leggiTabella(entry_t *log) {
  int nr = 0, i;
  FILE *in = fopen(FILE_IN, "r");
  if (in == NULL)
    exit(-1);
  fscanf(in, "%d", &nr);
  for (i=0; i<nr; i++) {
    fscanf(in, "%s %s %s %s %s %s", log[i].ip, log[i].user, log[i].time, log[i].tipo, log[i].risorsa, log[i].risposta);
	sscanf (log[i].time,"%d/%d/%d", &log[i].data.g,&log[i].data.m,&log[i].data.a);
  }
  return nr;
}

comando_e leggiComando(char comandi[][STR]) {
  int i;
  char cmd[STR];
  printf("Comando > ");
  scanf("%s", cmd);
  for (i=0; i<CMD; i++) {
	if (strcmp(cmd, comandi[i]) == 0)
      return (comando_e) i;
  }
  return -1;
}

void stampaComandi(char comandi[][STR]) {
  int i;
  printf("Comandi disponibili:");
  for (i=0;i<CMD;i++)
    printf(" %s", comandi[i]);
  printf("\n");
}

void selezionaDati(entry_t log[], int nr, comando_e cmd) {
  data_t d1, d2;
  int tmp, i;
  if (cmd != r_rifiuto) {
    printf("Inserire prima data [gg/mm/aaaa]: ");
    scanf("%d/%d/%d", &d1.g,&d1.m,&d1.a);
    printf("Inserire seconda data [gg/mm/aaaa]: ");
    scanf("%d/%d/%d", &d2.g,&d2.m,&d2.a);
  }
  for (i=0; i<nr; i++) {
    int dataOK = 1;
    if (cmd != r_rifiuto) {
      dataOK = confrontaDate(d1, log[i].data)<=0 && confrontaDate(log[i].data, d2)<=0;
      if (dataOK) {
	    switch(cmd) {
		  case r_nome:
                    printf("%s\n", log[i].user);
					break;
          case r_ip:
                    printf("%s\n", log[i].ip);
					break;
          case r_rifiuto:
                    if(!strcmp(log[i].risposta, "401"))
                      printf("%s\n", log[i].user);
					break;
		  case r_risorsa:
                    printf("%s\n", log[i].risorsa);
					break;
        }
      }
    }
  }
}
