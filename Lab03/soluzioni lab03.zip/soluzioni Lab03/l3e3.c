#include<stdlib.h>
#include<stdio.h>

#define R 50
#define C 50

void leggiMatrice(char *file, int mat[][C], int *nr, int *nc);
void stampaMatrice(FILE *out, int mat[][C], int nr, int nc);
int verificaCammino(int mat[][C], int nr, int nc, int *p);

//void cammino(int mat[][C], int nr, int nc);
//int verificaCammino(int mat[][C], int x, int y, int px, int py, int *w, int *s);

int main(void) {
  int mat[R][C], nr, nc, i, j, p=0;
  leggiMatrice("l3e3.txt", mat, &nr, &nc);
  stampaMatrice(stdout, mat, nr, nc);
  if (verificaCammino(mat,nr,nc,&p))
    printf("Cammino corretto, semplice, di peso %d\n", p);
  else
	printf("Cammino non corretto\n");
  return 0;
}

void leggiMatrice(char *file, int mat[][C], int *nr, int *nc) {
  int i, j;
  FILE *in = fopen(file, "r");
  if (in == NULL)
    exit(-1);
  fscanf(in, "%d %d", nr, nc);
  for (i=0; i<*nr; i++)
    for (j=0; j<*nc; j++)
      fscanf(in, "%d", &mat[i][j]);
  fclose(in);
  return;
}

void stampaMatrice(FILE *out, int mat[][C], int nr, int nc) {
  int i, j;
  for (i=0; i<nr; i++) {
    for (j=0; j<nc; j++)
      fprintf(out, "%d ", mat[i][j]);
    fprintf(out, "\n");
  }
  return;
}

int verificaCammino(int mat[][C], int nr, int nc, int *p) {
  int x, y, px = -1, py = -1, continua = 1, peso = 0, ok = 1;
  printf("Inserisci passi del cammino ([-1, -1] per terminare)\n");
  do {
	scanf("%d %d", &x, &y);
	if (x == -1 && y == -1)
      continua = 0;
    else if (x >= 0 && y >= 0 && x < nr && y < nc) {
      if (mat[x][y] == 0) // cella nulla, non calpestabile
        return 0;

      if (mat[x][y] < 0) // celle a valore negativo sono state già viste: cammino non semplice !
        return 0;

      if ((px != -1 && py!= -1) && abs(x-px) > 1 || abs(y-py) > 1) // se c'è una posizione precedente e quella attuale rappresenta un salto, il cammino non va bene
        return 0;

      (*p) += mat[x][y];

	  mat[x][y] *= -1; // dopo il primo passaggio, inverti il valore: segnala passaggio

	  ok = 1;
      px = x;
      py = y;
    }
  } while(continua && ok);
  return ok;
}

