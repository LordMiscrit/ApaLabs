#include <stdlib.h>
#include <stdio.h>

typedef struct d_ {
	int *elementi;
	int n_elementi;
} d;

void stampa(d *v, int numd) {
  int i, j;
  for (i=0; i<numd; i++) {
    for (j=0; j<v[i].n_elementi; j++)
      printf("%d ", v[i].elementi[j]);
    printf("\n");
  }
}

void calcolaD(int **mat, d *D, int nr, int nc, int numd, int maxd) {
  int i, j, offset;
  offset = (nr > nc) ? nr-1 : nc-1;
  for (i=0; i<(maxd-1); i++) {
    D[i].elementi = calloc(i+1, sizeof(int));
	D[numd-i-1].elementi = calloc(i+1, sizeof(int));
  }
  if (numd % 2)
    D[numd/2].elementi = calloc(maxd, sizeof(int));

  for(i=0;i<nr;i++) {
	for(j=0;j<nc;j++)
	  D[i-j+offset].elementi[D[i-j+offset].n_elementi++] = mat[i][j];
  }
}

void calcolaA(int **mat, d *D, int nr, int nc, int numd, int maxd) {
  int i, j;
  for (i=0; i<(maxd-1); i++) {
    D[i].elementi = calloc(i+1, sizeof(int));
	D[numd-i-1].elementi = calloc(i+1, sizeof(int));
  }
  if (numd % 2)
    D[numd/2].elementi = calloc(maxd, sizeof(int));

	 for (j=0; j<nc; j++){
		for (i=0; i<nr; i++)
			D[i+j].elementi[D[i+j].n_elementi++] = mat[i][j];
	}
}

int **malloc2dR(int *nr, int *nc, FILE *fp) {
  fscanf(fp, "%d %d", nr, nc);
  int i, j, **mat = (int**) calloc(*nr, sizeof(int*));
  for (i=0; i<*nr; i++) {
    mat[i] = (int*) calloc(*nc, sizeof(int));
    for (j=0; j<*nc; j++)
      fscanf(fp, "%d", &mat[i][j]);
  }
  return mat;
}

void malloc2dP(int ***mat, int *nr, int *nc, FILE *fp) {
  fscanf(fp, "%d %d", nr, nc);
  int i, j;
  *mat = (int**) calloc(*nr, sizeof(int*));
  for (i=0; i<*nr; i++) {
    (*mat)[i] = (int*) calloc(*nc, sizeof(int));
    for (j=0; j<*nc; j++)
      fscanf(fp, "%d", &(*mat)[i][j]);
  }
}

int main(void) {
  int **mat, nr, nc, numd, maxd;
  FILE *fp = fopen("matrix.txt", "r");
  d *diag, *anti;
  if (fp == NULL)
    return -1;
  mat = malloc2dR(&nr, &nc, fp);
 // malloc2dP(&mat, &nr, &nc, fp);
  fclose(fp);

  numd = nr + nc -1;
  maxd = (nr > nc) ? nc : nr ;
  diag = calloc(numd, sizeof(d));
  anti = calloc(numd, sizeof(d));

  calcolaD(mat, diag, nr, nc, numd, maxd);
  calcolaA(mat, anti, nr, nc, numd, maxd);

  printf("Diagonali\n");
  stampa(diag, numd);
  printf("\nAntidiagonali\n");
  stampa(anti, numd);
  return 0;
}
