#include <stdlib.h>
#include <stdio.h>

int Q(int n) {
  if (n == 1 || n == 2)
    return 1;
  return Q(n - Q(n-1)) + Q(n - Q(n-2));
}

int Qmemo(int n, int *qmemo) {
  if (n == 1 || n == 2) {
	qmemo[n]  = 1;
	return qmemo[n];
  }
  if (qmemo[n] != 0)
    return qmemo[n];
  qmemo[n] = Qmemo(n - Qmemo(n-1, qmemo), qmemo) + Qmemo(n - Qmemo(n-2, qmemo), qmemo);
  return qmemo[n];
}

int main(void) {
  int n = 40, i, *qmemo;
  for (i=1; i<=n; i++)
    printf("%d ", Q(i));
  printf("\n\n");
  // Variante con memoization
  qmemo = calloc(n+1, sizeof(int));
  for (i=1; i<=n; i++)
    Qmemo(i, qmemo);
  for (i=1; i<=n; i++)
    printf("%d ", qmemo[i]);
}
