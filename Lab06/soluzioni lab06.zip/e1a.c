// soluzione A: la misura della distanza viene fatta cercando, mediante la funzione
// ricorsiva distanzaR, l'ultimo (più lontano dalla radice) antenato comune ai due nodi.
// da qui si attiva la funzione ricorsiva contaD, che misura la distanza tra quest e i 
// due nodi. Il risultato e' la somma delle due distanze.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXS 11 /* 10 + 1 per '\0' */

// Definizione delle strutture dati usate
typedef struct nodo *link;

struct nodo {
  char val[MAXS];
  link left;
  link right;
};

typedef char *Key;

int KEYcomp(Key a, Key b) {
  return strcmp(a, b);
}

// Prototipi delle funzioni di utilità
link new_nodo(char *val);
link leggi_nodo(FILE *in);
link leggi_albero(char *filename);
void libera_albero(link root);
void display_albero(link root);

// Prototipi delle funzioni da implementare
int distanza(link n, char *k1, char *k2);
int contaCompleti(link n, int L1, int L2);

int main(int argc, char **argv) {
  link root;
  root = leggi_albero(argv[1]);
  display_albero(root);

  // invocazione delle funzioni richieste
  printf("Il numero di nodi con 2 figli e': %d\n", contaCompleti(root, 0, 2));
  printf("Distanza = %d\n", distanza(root, "Aez", "H"));
  libera_albero(root);
  return 0;
}

// Implementazione delle funzioni di utilità

link new_nodo(char *val) {
  link n = malloc(1*sizeof(*n));
  strcpy (n->val,val);
  n->left = NULL;
  n->right = NULL;
  return n;
};


void display_albero(link root) {
  if (root == NULL)
    return;
  printf("nodo %s\n", root->val);
  display_albero(root->left);
  display_albero(root->right);
}

void libera_albero(link root) {
  if (root == NULL)
    return;
  libera_albero(root->left);
  libera_albero(root->right);
  free(root);
}

link leggi_nodo(FILE *in) {
  char val[MAXS];
  int l, r;
  link n;
  if (fscanf(in, "%s %d %d", val, &l, &r) != 3)
    return NULL;
  n = new_nodo(val);
  if (l!=0)
    n->left = leggi_nodo(in);
  if (r!=0)
    n->right = leggi_nodo(in);
  return n;
}

link leggi_albero(char *filename) {
  FILE *in;
  in = fopen(filename, "r");
  link root = leggi_nodo(in);
  fclose(in);
  return root;
}

// Implementazione delle funzioni da aggiungere

int contaD(link n, char *k, int *miss) {
  if (n == NULL) {
	*miss = 1;
	return 0;
  }
  if (KEYcomp(n->val, k) == 0)
    return 1;
  if (KEYcomp(n->val, k) > 0)
    return 1+contaD(n->left, k, miss);
  if (KEYcomp(n->val, k) < 0)
    return 1+contaD(n->right, k, miss);
  return 0;
}

int distanzaR(link n, char *k1, char *k2, int *miss) {
  if (n == NULL) {
	*miss = 1;
    return 0;
  }
  if(KEYcomp(n->val, k1) > 0 && KEYcomp(n->val, k2) > 0)
    return distanzaR(n->left, k1, k2, miss);
  if(KEYcomp(n->val, k1) < 0 && KEYcomp(n->val, k2) < 0)
    return distanzaR(n->right, k1, k2, miss);
  if(KEYcomp(n->val, k2) == 0)
    return contaD(n->left, k1, miss);
  if(KEYcomp(n->val, k1) == 0)
    return contaD(n->right, k2, miss);
  return  contaD(n->left, k1, miss) + contaD(n->right, k2, miss);
}

int distanza(link n, char *k1, char *k2) {
  // Assume k1 <= k2. Altrimenti basta scambiarli...
  int miss = 0;
  int dist = distanzaR(n, k1, k2, &miss);
  return (miss == 0) ? dist : -1;
}

int contaCompletiR(link n, int L1, int L2, int depth)  {
  int cnt = 0;
  if (n == NULL)
    return 0;
  if (depth > L2)
    return 0;
  // conta nodo corrente solo se completo e depth>=L1
  if (depth >= L1 && n->left != NULL && n->right != NULL)
    cnt = 1;
  cnt += contaCompletiR(n->left, L1, L2, depth+1); 
  cnt += contaCompletiR(n->right, L1, L2, depth+1);
  return cnt;
}

int contaCompleti(link n, int L1, int L2) {
  return contaCompletiR(n, L1, L2, 0);
}


