// soluzione B: la misura della distanza viene fatta misurando indipendentemente
// in due visite, la profondita' (lunghezza del percorso nodo-radice) dei due nodi. 
// Nel fare questo si tiene traccia del percorso comune.
// al termine si calcola la distanza come somma dei percorsi, a cui si sottrae 
// il tratto comune (contato 2 volte)

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#define MAXS 11 /* 10 + 1 per '\0' */

// Definizione delle strutture dati usate
typedef struct nodo *link;

struct nodo {
  char val[MAXS];
  int visitato;
  link left;
  link right;
};

typedef char *Key;

int KEYcomp(Key a, Key b) {
  return strcmp(a, b);
}

// Prototipi delle funzioni di utilità
link new_nodo(char *val);
link leggi_nodo(FILE *in);
link leggi_albero(char *filename);
void libera_albero(link root);
void display_albero(link root);

// Prototipi delle funzioni da implementare
int distanza(link n, char *k1, char *k2);
int contaCompleti(link n, int L1, int L2);

int main(int argc, char **argv) {
  link root;
  root = leggi_albero(argv[1]);
  display_albero(root);

  // invocazione delle funzioni richieste
  printf("Il numero di nodi con 2 figli e': %d\n", contaCompleti(root, 0, 2));
  printf("Distanza = %d\n", distanza(root, "Aez", "H"));
  libera_albero(root);
  return 0;
}

// Implementazione delle funzioni di utilità

link new_nodo(char *val) {
  link n = malloc(1*sizeof(*n));
  strcpy (n->val,val);
  n->visitato=0;
  n->left = NULL;
  n->right = NULL;
  return n;
};


void display_albero(link root) {
  if (root == NULL)
    return;
  printf("nodo %s\n", root->val);
  display_albero(root->left);
  display_albero(root->right);
}

void libera_albero(link root) {
  if (root == NULL)
    return;
  libera_albero(root->left);
  libera_albero(root->right);
  free(root);
}

link leggi_nodo(FILE *in) {
  char val[MAXS];
  int l, r;
  link n;
  if (fscanf(in, "%s %d %d", val, &l, &r) != 3)
    return NULL;
  n = new_nodo(val);
  if (l!=0)
    n->left = leggi_nodo(in);
  if (r!=0)
    n->right = leggi_nodo(in);
  return n;
}

link leggi_albero(char *filename) {
  FILE *in;
  in = fopen(filename, "r");
  link root = leggi_nodo(in);
  fclose(in);
  return root;
}

// Implementazione delle funzioni da aggiungere

int contaR(link n, char *k, int *comuniP) {
  if (n == NULL) {
    return -1;
  }
  if (n->visitato>0) (*comuniP)++;
  n->visitato++;
  if (KEYcomp(n->val, k) == 0)
    return 1;
  if (KEYcomp(n->val, k) > 0)
    return 1+contaR(n->left, k, comuniP);
  if (KEYcomp(n->val, k) < 0)
    return 1+contaR(n->right, k, comuniP);
  return 0;
}

int distanza(link n, char *k1, char *k2) {
  int comuni=0, n1, n2;

  n1 = contaR(n, k1, &comuni);
  assert(comuni==0);
  n2 = contaR(n, k2, &comuni);

  if (n1<0 || n2<0) return -1;
  // n1 e n2 contano i nodi (-1 per gli archi) togliere
  // diatanza = (n1-1) + (n2-1) - (comuni-1)
  else return (n1+n2-comuni-1);
}

int contaCompletiR(link n, int L1, int L2, int depth)  {
  int cnt = 0;
  if (n == NULL)
    return 0;
  if (depth > L2)
    return 0;
  // conta nodo corrente solo se completo e depth>=L1
  if (depth >= L1 && n->left != NULL && n->right != NULL)
    cnt = 1;
  cnt += contaCompletiR(n->left, L1, L2, depth+1); 
  cnt += contaCompletiR(n->right, L1, L2, depth+1);
  return cnt;
}

int contaCompleti(link n, int L1, int L2) {
  return contaCompletiR(n, L1, L2, 0);
}


