#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

typedef struct {
  float x, y, dist;
} Item;

typedef float Key;

typedef struct node *link;

struct node {
  Item point;
  link next;
};

typedef struct {
  link head;
} list;

Key KEYget(Item point)  {
  return point.dist;
}

int KEYgreater(Key k1, Key k2)  {
  return (k1>k2);
}

float distFromOrig(Item point) {
	return sqrt(point.x*point.x + point.y*point.y);
}

Item ITEMscan() {
  float x, y;
  Item point;
  printf("x= ");
  scanf("%f", &x);
  printf("y= ");
  scanf("%f", &y);
  point.x = x;
  point.y = y;
  point.dist = distFromOrig(point);
  return point;
}

void ITEMdisplay(Item point) {
  printf("<%f, %f> [%f]\n", point.x, point.y, point.dist);
}

list *listInit() {
  list *l = malloc(sizeof(list));
  if (l == NULL)
    return NULL;
  l->head = NULL;
  return l;
}

link newNode(Item point, link next) {
  link x = malloc(sizeof *x);
  if (x == NULL)
    return NULL;
  x->point = point;
  x->next = next;
  return x;
}

void listDisplay(list *l) {
  link tmp;
  if (l == NULL)
    return;
  tmp = l->head;
  while(tmp != NULL) {
    ITEMdisplay(tmp->point);
    tmp = tmp->next;
  }
}

void SortListIns(list *l, Item point) {
  link x, p;
  Key k = KEYget(point);
  if (l->head==NULL || KEYgreater(KEYget(l->head->point),k)) {
    l->head = newNode(point, NULL);
  }
  else {
    for (x=l->head->next, p=l->head; x!=NULL && KEYgreater(k,KEYget(x->point)); p=x, x=x->next);
    p->next = newNode(point, x);
  }
}


int main(void) {
  int i, n=4;
  list *l = listInit();
  Item point;
  for (i=0; i<n; i++) {
    printf("Inserire coordinate del prossimo punto:\n");
	point = ITEMscan();
    SortListIns(l, point);
  }
  printf("La lista ordinata per distanze dall'origine crescenti e': \n");
  listDisplay(l);
  return 0;
}
