#ifndef INGREDIENTE_H_DEFINED
#define INGREDIENTE_H_DEFINED
#define LEN 256

#include<string.h>
#include<stdlib.h>
#include<stdio.h>


typedef struct {
	char *nome;
	float prezzo;
	float cal;
} ingrediente;

typedef struct node *link;

struct node {
  ingrediente *ing;
  link next;
};


typedef struct {
  link head, tail;
  int nIngr;
} list;

list *leggiIngredienti(FILE *fin);
void stampaIngredienti(list *ingredienti, FILE *fout);
ingrediente *cercaIngrediente(char *nomeIngr, list *ingredienti);

#endif
