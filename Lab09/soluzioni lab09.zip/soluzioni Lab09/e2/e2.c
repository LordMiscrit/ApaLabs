#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<time.h>

#include "pq.h"
#include "item.h"

#define N_SCELTE 7

void stampaMenu(char *scelte[], int *selezione);
void gioca();

int main(int argc, char **argv) {

  srand((unsigned)time(NULL));

  char *scelte[] = {
		"Uscita",
		"Stampa classifica",
		"Inserisci partecipante",
		"Elimina partecipante",
		"Gioca",
		"Carica",
		"Salva",
	};

  int selezione, fineProgramma = 0;
  Item item;
  Key k;
  char tmp[MAX];
  FILE *fp;

  do {
		stampaMenu(scelte, &selezione);
		switch(selezione) {

			case 0: {
              fineProgramma = 1;
		   } break;
            case 1: {
              PQsort();
            } break;
            case 2: {
              printf("Inserisci id partecipante > ");
              item = ITEMscan(stdin);
              PQinsert(item);
            } break;
            case 3: {
              printf("Inserisci id partecipante > ");
              k = KEYscan();
              PQremove(k);
            } break;
            case 4: {
              gioca();
              PQsort();
            } break;
            case 5: {
              printf("Inserisci nome file > ");
              scanf("%s", tmp);
              fp = fopen(tmp, "r");
              PQload(fp);
              fclose(fp);
            } break;
            case 6: {
              printf("Inserisci nome file > ");
              scanf("%s", tmp);
              fp = fopen(tmp, "w");
              PQstore(fp);
              fclose(fp);
            } break;
			default:{
              printf("Scelta non valida\n");
			} break;
		}
	} while(!fineProgramma);

	return 0;
}

void stampaMenu(char *scelte[], int *selezione){
  int i=0;
  printf("MENU'\n");
	for(i=0;i<N_SCELTE;i++) printf("  %d) %s\n",i,scelte[i]);
	printf("Scelta: ");
  scanf("%d",selezione);
}


void gioca() {
  Item a, b;
  if (PQsize() < 2)
    return;
  a = PQreadMin();
  PQremove(KEYget(&a));
  b = PQreadMin();
  PQremove(KEYget(&b));
  int rnd = rand() < RAND_MAX/2;
  if (rnd == 0) {
    // Vince A
    ITEMchange(&a, &b, 0.25);
  } else {
    // Vince B
    ITEMchange(&b, &a, 0.25);
  }
  if (!ITEMzero(a))
    PQinsert(a);
  if (!ITEMzero(b))
    PQinsert(b);

  return;
}
