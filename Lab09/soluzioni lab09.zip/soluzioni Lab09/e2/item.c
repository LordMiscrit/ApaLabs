#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "item.h"

Item ITEMscan(FILE *fp) {
  Item item;
  fscanf(fp, "%s %f", item.nome, &(item.p));
  return item;
}

void ITEMstore(FILE *fp, Item x) {
  fprintf(fp, "nome= %s punti = %.3f\n", x.nome, x.p);
}

Item ITEMnew(Key k, float p) {
  Item item;
  item.p = p;
  strcpy(item.nome, k);
  return item;
}

void ITEMchange(Item *a, Item *b, float ratio) {
   (*a).p += (*b).p*0.25;
   (*b).p = (*b).p*0.75;
}

int  ITEMzero(Item a) {
   if (a.p < 0.01)
     return 1;
   else
      return 0;
}

Key KEYscan() {
  char tmp[MAX];
  Key k;
  scanf("%s", tmp);
  k = strdup(tmp);
  return k;
}

Key KEYget(Item *x) {
  return (x->nome);
}

int KEYeq(Key k1, Key k2) {
  return (strcmp(k1,k2)==0);
}

float GETprio(Item *x)  {
  return (x->p);
}
