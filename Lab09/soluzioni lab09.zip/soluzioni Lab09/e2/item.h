#ifndef ITEM_H_DEFINED
#define ITEM_H_DEFINED

#include <stdio.h>
#define MAX 31

typedef struct {
  float p;
  char nome[MAX];
} Item;

typedef char *Key;

Item ITEMscan(FILE *fp);
Item ITEMnew(Key k, float p);
void ITEMstore(FILE *fp, Item x);
void ITEMchange(Item *a, Item *b, float ratio);
int  ITEMzero(Item a);

Key KEYscan();
Key KEYget(Item *x);
int KEYeq(Key k1, Key k2);
float GETprio(Item *x);


#endif
