#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "pq.h"

typedef struct PQnode* link;
struct PQnode { Item item; link next; };

static link head;
static int nElem;

typedef struct {
  char *n;
  float p;
} rank;

static link NEWnode(Item item, link next) {
  link x = (link) malloc(sizeof *x);
  x->item = item;
  x->next = next;
  return x;
}

void PQinit() {
  head = NULL;
  nElem = 0;
}

int PQempty() {
  return head == NULL;
}

int PQsize() {
  return nElem;
}

void PQload(FILE *fp){
  int i, cnt;
  fscanf(fp, "%d", &cnt);
  for(i=0;i<cnt;i++) {
    PQinsert(ITEMscan(fp));
  }
}

void PQstore(FILE *fp){
  link iter = head;
  fprintf(fp, "%d\n", nElem);
  while(iter != NULL) {
    ITEMstore(fp, iter->item);
    iter = iter->next;
  }
}

void PQinsert(Item item) {
  if (head == NULL) {
    head = NEWnode(item, NULL);
    nElem = 1;
  } else {
    head = NEWnode(item, head);
    nElem++;
  }
}

void PQremove(Key k) {
  link iter, prev;
  if (head == NULL)
    return;
    if (KEYeq(KEYget(&(head->item)),k)) {
      head = head->next;
      nElem--;
    return;
  }
  for(iter = head->next, prev = head; iter != NULL; iter = iter->next, prev = prev->next) {
    if (KEYeq(KEYget(&(iter->item)),k)) {
      prev->next = iter->next;
      free(iter);
      nElem--;
    }
  }
}

Item PQreadMin() {
  if (head != NULL) {
    Item minItem = head->item;
    link iter = head;
    while (iter != NULL) {
      if (iter->item.p < minItem.p) minItem = iter->item;
      iter = iter->next;
    }
    return minItem;
  } else {
    return ITEMnew("", -1);
  }
}


void PQsort(){
  link iter = head;
  int i = 0, j;
  Item tmp;
  printf("Partecipanti: %d\nClassifica: \n", nElem);
  Item *R = calloc(nElem, sizeof(Item));
  while(iter != NULL) {
    R[i++] = ITEMnew(KEYget(&(iter->item)), iter->item.p);
    iter = iter->next;
  }
  for (i=0; i<nElem-1; i++) {
    for (j=i+1; j<nElem; j++) {
      if (GETprio(&R[i]) < GETprio(&R[j])) {
        tmp = R[i];
        R[i] = R[j];
        R[j] = tmp;
      }
    }
  }

  for(i=0;i<nElem;i++) {
    ITEMstore(stdout,R[i]);
  }
  free(R);
}

/*

void PQsort(){
  link iter = head;
  int i = 0, j;
  printf("Partecipanti: %d\nClassifica: \n", nElem);
  rank *R = calloc(nElem, sizeof(rank));
  while(iter != NULL) {
    R[i].n = iter->item.nome;
    R[i++].p = iter->item.p;
    iter = iter->next;
  }
  for(i=0;i<nElem-1;i++) {
    for(j=i+1;j<nElem;j++) {
      if (R[i].p < R[j].p) {
        rank tmp = R[i];
        R[i] = R[j];
        R[j] = tmp;
      }
    }
  }

  for(i=0;i<nElem;i++) {
    printf(" %d) %s %.3f\n", i+1, R[i].n, R[i].p);
  }
  free(R);
}
*/
