#ifndef PQ_H_DEFINED
#define PQ_H_DEFINED

#include "item.h"

void    PQinit();
int     PQempty();
int     PQsize();
void    PQload(FILE *fp);
void    PQstore(FILE *fp);
void    PQinsert(Item x);
void    PQremove(Key k);
Item    PQreadMin();
void    PQsort();

#endif
