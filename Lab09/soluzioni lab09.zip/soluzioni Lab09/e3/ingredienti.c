#include "ingredienti.h"
#include "ricette.h"

/*
  Onde evitare riferimenti circolari, un ingrediente conosce le ricette di cui fa parte solo per nome.
  Questo comporta la necessit� di check di consistenza, se fosse possibile cambiare il nome di una specifica ricetta.
*/

typedef struct elenco_ {
  char *r;
  struct elenco_ *next;
} elenco;

typedef struct elenco_ elenco;

struct ingrediente_ {
  char *nome;
  float prezzo;
  float cal;
  elenco *head, *tail;
};

typedef struct ingrediente_ ingrediente;

struct tabIngr_ {
  ingrediente *vettIng;
  int nIngr;
};

tabIngr_p INGleggiCollezione(FILE *in) {
  int i;
  tabIngr_p ingredienti = calloc(1, sizeof(*ingredienti));
  if (ingredienti == NULL)
    return NULL;
  fscanf(in, "%d", &ingredienti->nIngr);

  // La collezione ha visibilit� dei dettagli di un certo ingrediente (sono moduli allo stesso livello gerarchico) e quindi pu� allocare un vettore di
  // strutture ingrediente

  ingredienti->vettIng = calloc(ingredienti->nIngr, sizeof(ingrediente));
  if (ingredienti->vettIng == NULL)
    return NULL;
  for (i=0; i<ingredienti->nIngr; i++)
    INGleggi(in, &(ingredienti->vettIng[i]));
  return ingredienti;
}

void INGleggi(FILE *in, ingrediente *ing) {
  char nomeTmp[LEN];
  float prezzo, cal;
  fscanf(in, "%s %f %f", nomeTmp, &prezzo, &cal);
  ing->nome = strdup(nomeTmp);
  ing->prezzo = prezzo;
  ing->cal = cal;
  ing->head = ing->tail = NULL;
}

ingrediente *INGcerca(char *nomeIngr, tabIngr_p ingredienti) {
  int i;
  if (ingredienti == NULL || ingredienti->vettIng == NULL)
    return NULL;
  for (i=0; i<ingredienti->nIngr; i++)
    if (strcmp(nomeIngr, ingredienti->vettIng[i].nome) == 0)
      return &(ingredienti->vettIng[i]);
  return NULL;
}

void INGstampaCollezione(tabIngr_p ingredienti, FILE *out) {
  int i;
  if (ingredienti == NULL || ingredienti->vettIng == NULL)
    return;
  for (i=0; i<ingredienti->nIngr; i++)
    fprintf(out, "%s %.2f e/Kg %.2f cal/g\n", ingredienti->vettIng[i].nome, ingredienti->vettIng[i].prezzo, ingredienti->vettIng[i].cal);
  printf("\n\n");

}

void INGstampa(ingrediente_p ing, FILE *out) {
 fprintf(out, "%s %.2f e/Kg %.2f cal/g\n", ing->nome, ing->prezzo, ing->cal);
}

float INGgetPrezzo(ingrediente_p ing) {
  return ing->prezzo;
}

float INGgetCalorie(ingrediente_p ing) {
  return ing->cal;
}
char* INGgetNome(ingrediente_p ing) {
  return ing->nome;
}


void INGstampaRicette(ingrediente_p ing, FILE *out) {
  elenco *iter = ing->head;
  while(iter != NULL) {
    printf("%s\n", iter->r);
    iter = iter->next;
  }
}

void INGaggiornaRicette(ingrediente_p ing, char* r) {

 elenco *el = calloc(1, sizeof(*el));
 el->r = strdup(r);
 if (ing->head == NULL)
   ing->head = ing->tail = el;
  else {
    ing->tail->next = el;
    ing->tail = el;
  }
}
