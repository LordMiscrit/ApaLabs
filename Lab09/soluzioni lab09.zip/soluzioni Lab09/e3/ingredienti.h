#ifndef INGREDIENTI_H_DEFINED
#define INGREDIENTI_H_DEFINED
#define LEN 256

#include<string.h>
#include<stdlib.h>
#include<stdio.h>

/*Il modulo esporta come ADT di prima categoria sia il singolo ingrediente, sia la collezione */

typedef struct tabIngr_ *tabIngr_p;
typedef struct ingrediente_ *ingrediente_p;

void INGleggi(FILE *in, ingrediente_p ing);
tabIngr_p INGleggiCollezione(FILE *in);
void INGstampa(ingrediente_p ing, FILE *out);
void INGstampaRicette(ingrediente_p ing, FILE *out);
void INGstampaCollezione(tabIngr_p ingredienti, FILE *out);
ingrediente_p INGcerca(char *nomeIngr, tabIngr_p ingredienti);
float INGgetPrezzo(ingrediente_p ing);
float INGgetCalorie(ingrediente_p ing);
char *INGgetNome(ingrediente_p ing);
void INGaggiornaRicette(ingrediente_p ing, char* r);

#endif
