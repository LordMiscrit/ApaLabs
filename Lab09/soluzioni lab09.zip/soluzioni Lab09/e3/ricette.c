#include "ricette.h"

struct tabRicette_ {
  ricetta_p head, tail;
  int nRicette;
};

typedef struct rIng_ {
  int qta;
  struct rIng_ *next;
  ingrediente_p ing;
} rIng;

struct ricetta_ {
  int tempo;
  int nIngr;
  char *nomeRicetta;
  float costo, cal;
  rIng *head, *tail;
  struct ricetta_ *next;
};

typedef struct ricetta_ ricetta;

ricetta_p RICleggi(FILE *in, tabIngr_p ingredienti) {
  int tempo, ni, i, qta;
  float costo = 0, cal = 0;
  char nomeR[LEN], nomeI[LEN];
  ricetta *r = calloc(1, sizeof(ricetta));
  rIng *ing;

  if (r == NULL)
    return NULL;
  if (in == stdin)
    printf("Inserire <nomeRicetta> <tempo> <numIngr>\n");

  fscanf(in, "%s %d %d", nomeR, &tempo, &ni);
  r->nomeRicetta = strdup(nomeR);
  r->tempo = tempo;
  r->nIngr = ni;

  for (i=0; i<ni; i++) {
    if (in == stdin)
      printf("Inserire <nomeIngrediente> <qta>\n");
    fscanf(in, "%s %d", nomeI, &qta);
    ing = calloc(1, sizeof(rIng));
    if (ing == NULL)
      return NULL;
    ing->ing = INGcerca(nomeI, ingredienti);
    if (ing->ing == NULL) {
      free(ing);
      continue;
    }

    INGaggiornaRicette(ing->ing, nomeR);
    ing->qta = qta;
    ing->next = NULL;
    if (ing->ing != NULL) {
      costo += (qta * INGgetPrezzo(ing->ing) / 1000.0) ;
      cal += (qta * INGgetCalorie(ing->ing)) ;
    }
    if (r->head == NULL)
      r->head = r->tail = ing;
    else {
      r->tail->next = ing;
      r->tail = ing;
    }
  }
  r->costo = costo;
  r->cal = cal;
  return r;
}

tabRicette_p RICleggiCollezione(FILE *in, tabIngr_p ingredienti) {
  int i;
  ricetta *r;
  tabRicette_p ricette = calloc(1, sizeof(*ricette));
  if (ricette == NULL)
    return NULL;
  fscanf(in, "%d", &ricette->nRicette);
  for (i=0; i<ricette->nRicette; i++) {
    r = RICleggi(in, ingredienti);
    if (ricette->head == NULL)
      ricette->head = ricette->tail = r;
    else {
      ricette->tail->next = r;
      ricette->tail = r;
    }
  }
  return ricette;
}

ricetta_p RICcerca(char *nomeRicetta, tabRicette_p ricette) {
  ricetta_p iter;
  if (ricette == NULL)
    return NULL;
  iter = ricette->head;
  while (iter != NULL && strcmp(iter->nomeRicetta, nomeRicetta))
    iter = iter->next;
  return iter;
}

void RICcrea(tabRicette_p ricette, tabIngr_p ingredienti) {
  ricetta *r;
  if (ricette == NULL || ingredienti == NULL)
    return;
  r = RICleggi(stdin, ingredienti);
  if (ricette->head == NULL) {
    ricette->head = ricette->tail = r;
    return;
  }
  ricette->tail->next = r;
  ricette->tail = r;
  ricette->nRicette++;
}

void RICstampa(ricetta *ric, FILE *out) {
  rIng *iter;
  if (ric == NULL)
    return;
  printf("%s\n", ric->nomeRicetta);
  iter = ric->head;
  while(iter != NULL) {
    printf("\t%s %d\n", INGgetNome(iter->ing), iter->qta);
    iter = iter->next;
  }
}

void RICstampaCollezione(tabRicette_p ricette, FILE *out) {
  ricetta *iter;
  if (ricette == NULL)
    return;
  iter = ricette->head;
  while(iter != NULL) {
    RICstampa(iter, out);
    iter = iter->next;
  }
}

float RICgetPrezzo(ricetta_p r) {
  return r->costo;
}

float RICgetCalorie(ricetta_p r) {
  return r->cal;
}

char* RICgetNome(ricetta_p r) {
  return r->nomeRicetta;
}
