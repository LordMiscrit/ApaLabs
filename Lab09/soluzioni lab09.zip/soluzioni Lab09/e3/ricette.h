#ifndef RICETTE_H_DEFINED
#define RICETTE_H_DEFINED

#include<string.h>
#include<stdlib.h>
#include<stdio.h>

#include "ingredienti.h"

/*Il modulo esporta come ADT di prima categoria sia la singola ricetta, sia la collezione */

typedef struct tabRicette_ *tabRicette_p;
typedef struct ricetta_ *ricetta_p;

ricetta_p RICleggi(FILE *in, tabIngr_p ingredienti);
ricetta_p RICcerca(char *nomeRicetta, tabRicette_p ricette);
tabRicette_p RICleggiCollezione(FILE *in, tabIngr_p ingredienti);
void RICcrea(tabRicette_p ricette, tabIngr_p ingredienti);
void RICstampa(ricetta_p ric, FILE *out);
void RICstampaCollezione(tabRicette_p ricette, FILE *out);
float RICgetPrezzo(ricetta_p r);
float RICgetCalorie(ricetta_p r);
char *RICgetNome(ricetta_p r);

#endif
