#include <stdio.h>
#include <stdlib.h>
#include "BST.h"

typedef struct BSTnode* link;
struct BSTnode { skier val; link l; link  r;} ;
struct binarysearchtree { link root; int num_nod; link z; };

void tree_print(FILE *fp, link h);
void tree_free(link h);
link NEW(skier d, link l, link r);

// Implementazione delle funzioni esposte all'esterno

BST BSTinit(void) {
  BST bst = malloc(sizeof *bst) ;
  if (bst == NULL) {
    printf("Errore di allocazione di memoria\n");
    exit(1);
  }
  bst->root = ( bst->z = NEW(NULL, NULL, NULL));
  bst->num_nod = 0;
  return bst;
}

int BSTempty(BST bst) {
 return (bst->num_nod==0);
}

int BSTcount(BST bst) {
  if (BSTempty(bst))
    return 0;
  return bst->num_nod;
}

skier searchR(link h, int id, link z) {
  if (h == z)
    return NULL;
  if (SKIERid(h->val) == id)
    return h->val;
  if (SKIERid(h->val) > id)
    return searchR(h->l, id, z);
  else
    return searchR(h->r, id, z);
  }

skier BSTsearch(BST bst, int id) {
  return searchR(bst->root, id, bst->z);
}

link insertR(link h, skier d, link z) {
  if (h == z)
    return NEW(d, z, z);

  if (SKIERid(h->val) == SKIERid(d)) /* salta duplicati */
    return h;

  if (SKIERid(h->val) > SKIERid(d))
    h->l = insertR(h->l, d, z);
  else
    h->r = insertR(h->r, d, z);
  return h;
}

void BSTinsert_leaf(BST bst, skier d) {
  bst->root = insertR(bst->root, d, bst->z);
  bst->num_nod++;
}


void BSTfree(BST bst) {
  if (bst == NULL)
    return;
  tree_free(bst->root);
  free(bst);
}

void BSTprint(FILE *fp, BST bst) {
  if (bst == NULL)
    return;
  tree_print(fp, bst->root);
}

// Funzioni interne al modulo

link NEW(skier d, link l, link r) {
  link x = malloc(sizeof *x);
  if (x == NULL) {
    printf("Errore di allocazione di memoria\n");
    exit(1);
  }
  x->val = d; x->l = l; x->r = r;
  return x;
}


void tree_print(FILE *fp, link h) {
  if (h == NULL)
    return;

  tree_print(fp, h->l);
  SKIERprint(fp, h->val);
  tree_print(fp, h->r);
}

void tree_free(link h) {
  if (h == NULL)
    return;
  tree_free(h->l);
  tree_free(h->r);
  SKIERfree(h->val);
  free(h);
}
