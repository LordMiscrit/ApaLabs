#ifndef _BSTINCLUDED
#define _BSTINCLUDED
#include "skier.h"

typedef struct binarysearchtree* BST;

BST BSTinit(void);
int BSTempty(BST t);
int BSTcount(BST t);
skier BSTsearch(BST t, int id);
void BSTprint(FILE *fp, BST t);
void BSTinsert_leaf(BST t, skier d);
void BSTfree(BST t);

#endif

