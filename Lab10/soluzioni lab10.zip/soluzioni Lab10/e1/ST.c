#include <stdlib.h>
#include <string.h>
#include "ST.h"

struct symboltable {skilift *a; int maxN; int size;};

static char *key(skilift s) {
    return SKILIFTid(s);
}

ST STinit(int maxN) {
  ST st = malloc(sizeof (struct symboltable));
  st->a = (skilift *) malloc(maxN * sizeof (skilift));
  st->maxN = maxN;
  st->size = 0;
  return st;
}

void STfree(ST st) {
  int id = 0;
  if (st==NULL)
    return;

  for (id=0; id<st->size; id++)
    if (st->a[id] != NULL)
      SKILIFTfree(st->a[id]);
  free(st->a);
  free(st);
}

int STcount(ST st) {
  return st->size;
}

int STinsert(ST st, char *str, int time) {
  int id = st->size;
  if (st->size >= st->maxN) {
    st->a = realloc(st->a, (2*st->maxN)*sizeof(skilift));
    if (st->a == NULL)
      return -1;
    st->maxN = 2*st->maxN;
  }
  st->a[id] = SKILIFTnew(str, time);
  st->size++;
  return id;
}

int STsearch(ST st, char *str) {
  int id;
  for (id=0; id<st->size; id++) {
    if (strcmp(str,key(st->a[id]))==0)
      return id;
  }
  return -1;
}

int STsearchOrInsert(ST st, char *str, int time) {
  int id = STsearch(st,str);
  if (id>=0)
    return id;
  else
    return STinsert(st,str, time);
}

skilift STretrieve(ST st, int id) {
  if (id < 0 || id>=st->size)
    return NULL;
  else
    return st->a[id];
}
