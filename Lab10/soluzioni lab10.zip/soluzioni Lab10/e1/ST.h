#ifndef ST_H_INCLUDED
#define ST_H_INCLUDED

#include "skilift.h"

typedef struct symboltable *ST;

ST STinit(int maxN);
void STfree(ST t);
int STcount(ST t);
int STsearch(ST t, char *str);
int STsearchOrInsert(ST t, char *str, int time);
int STinsert(ST t, char *str, int time);
skilift STretrieve(ST t, int id);

#endif // TS_H_INCLUDED
