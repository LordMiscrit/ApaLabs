#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include "ST.h"
#include "BST.h"
#include "skilift.h"
#include "skier.h"

#define MAX 11

int authorize (int cardId, char *skiliftId, int time, ST skilifts, BST skiers);
void readSkiliftData(char *fname, ST skilifts);

int main(int argc, char **argv) {
  int i, id, time;
  char sk[MAX];
  FILE *in = fopen(argv[2], "r");
  ST skilifts;
  BST skiers;

  skilifts = STinit(1);
  skiers = BSTinit();

  readSkiliftData(argv[1], skilifts);

  while(fscanf(in, "%s %d %d",  sk, &id, &time) == 3) {
    printf("Passaggio %sautorizzato per %d su %s alle %d\n", authorize(id, sk, time, skilifts, skiers) ? "" : "NON ", id, sk, time);
  }

  printf("\n");

  for (i=0; i <= BSTcount(skiers); i++)
    SKIERlistSkilifts(BSTsearch(skiers, i), skilifts);

  return 0;
}

int authorize (int cardId, char *skiliftId, int time, ST skilifts, BST skiers) {
  int skiliftIndex = STsearch(skilifts, skiliftId);
  if (skiliftIndex < 0)
    return 0;
  int n_skilifts = STcount(skilifts);

  skilift this_skilift = STretrieve(skilifts, skiliftIndex);
  skier s = BSTsearch(skiers, cardId);
  if (s == NULL) {
    // sciatore non trovato. L'autorizzazione � automatica dopo l'aggiunta nel BST
    s = SKIERnew(cardId, n_skilifts);
    BSTinsert_leaf(skiers, s);
    SKIERsetTime(s, time, skiliftIndex);
    return 1;
  }
  // sciatore di cui verificare l'autorizzazione
  int last_time = SKIERgetTime(s, skiliftIndex);
  if ((last_time == -1) || (time - last_time) > SKILIFTinterval(this_skilift)) {
    SKIERsetTime(s, time, skiliftIndex);
    return 1;
  } else
    return 0;
}

void readSkiliftData(char *fname, ST skilifts) {
  FILE *in = fopen(fname, "r");
  char id[MAX];
  int time;
  while(fscanf(in, "%s %d", id, &time) == 2) {
    STsearchOrInsert(skilifts, id, time);
  }
  fclose(in);
}

