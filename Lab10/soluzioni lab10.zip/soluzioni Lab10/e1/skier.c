
#include "skier.h"

struct user {
  int id;
  int *skiersSkilifts;
};

void SKIERprint(FILE *fp, skier s) {
  if (s != NULL)
    fprintf(fp, "%d", s->id);
}

int SKIERid(skier s) {
  return s->id;
}

void SKIERfree(skier s) {
  if (s == NULL)
    return;
  free(s->skiersSkilifts);
  free(s);
}

skier SKIERnew(int id, int n_skilift) {
  skier tmp = (skier) malloc(sizeof(struct user));
  int i;
  if (tmp != NULL) {
    tmp->id = id;
    tmp->skiersSkilifts = calloc(n_skilift, sizeof(int));
  }
  for (i=0; i<n_skilift; i++)
    tmp->skiersSkilifts[i] = -1;
  return tmp;
}

void SKIERsetTime(skier s, int time, int indice_skilift) {
  s->skiersSkilifts[indice_skilift] = time;
}
int SKIERgetTime(skier s, int indice_skilift) {
  return s->skiersSkilifts[indice_skilift];
}

void SKIERlistSkilifts(skier s, ST skilift) {
  int i;
  if (s == NULL)
    return;
  printf("Elenco di skilift usati da %d\n", s->id);
  for (i=0; i<STcount(skilift); i++) {
    if (s->skiersSkilifts[i] >= 0)
      printf("  %s (ultimo passaggio: %d)\n", SKILIFTid(STretrieve(skilift, i)), s->skiersSkilifts[i]);
  }
}
