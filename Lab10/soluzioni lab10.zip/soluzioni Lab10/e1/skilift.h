#ifndef _SKI_INCLUDED
#define _SKI_INCLUDED

#define MAX 11

typedef struct ski_lift* skilift;

char *SKILIFTid(skilift s);
void SKILIFTfree(skilift s);
skilift SKILIFTnew(char *str, int time);
int SKILIFTinterval(skilift s);

#endif
