#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Graph.h"

#define DBG 0

typedef struct node_ {
  int index;
  int weight;
  struct node_ *next;
} node;

struct G {
  int **madj;
  node **ladj;
  int V;
};

static node *newNode(int dst, int w, node *next);
static node* listInsHead(node *next, int dst, int w);

Graph GRAPHinit(int nV) {
  int i;
  Graph g = malloc(sizeof(*g));
  if (g == NULL)
    return NULL;
  g->V = nV;
  g->ladj = malloc(nV*sizeof(node*));
  for (i=0; i<nV; i++)
    g->ladj[i] = NULL;
  g->madj = NULL; // questo campo viene inizializzato solo su richiesta
  return g;
}

void GRAPHinsertE(Graph g, int src, int dst, int w, int flag) {
  if(src < 0 || dst < 0)
    return;
  if (w < 0)
    return;
  if (flag == 0) {
    if (g->ladj == NULL)
      return;
    g->ladj[src] = listInsHead(g->ladj[src], dst, w);
    g->ladj[dst] = listInsHead(g->ladj[dst], src, w);
  } else {
    if (g->madj == NULL)
      return;
    g->madj[src][dst] = g->madj[dst][src] = w;
  }
  return;
}

static node *newNode(int dst, int w, node *next) {
  node *n;
  n = (node *)malloc(sizeof(node));
  if (n == NULL)
    exit(-1);
  n->index = dst;
  n->weight = w;
  n->next = next;
  return n;
}

static node* listInsHead(node *h, int dst, int w) {
  h = newNode(dst, w, h);
  return h;
}

int GRAPHlist2mat(Graph g) {
  int i, j;
  node *iter;
  if (g->madj != NULL)
    return 0;
  if (g->ladj == NULL)
    return -1;
  g->madj = malloc(g->V * sizeof(int*));
  if (g->madj == NULL)
    return -1;
  for (i=0; i<g->V; i++) {
    g->madj[i] = malloc(g->V * sizeof(int));
    if (g->madj[i] == NULL)
      return -1;
    for (j=0; j<g->V; j++)
      g->madj[i][j] = 0;
    iter = g->ladj[i];
    while(iter != NULL) {
      g->madj[i][iter->index] = iter->weight;
      iter = iter->next;
    }
  }

#if DBG
    for(i=0;i<g->V;i++) {
        for(j=0;j<g->V;j++) fprintf(stdout, "%4d ", g->madj[i][j]);
        fprintf(stdout, "\n");
    }
#endif // DBG

  return 0;
}

void GRAPHadjacent(Graph g, int *adjacentN, int *adjacentW, int index, int flag) {
  int i=0, j;
  node *iter;
  if (flag == 0) {
    if (g->ladj == NULL)
      return;
    iter = g->ladj[index];
    while (iter != NULL) {
      adjacentN[i] = iter->index;
      adjacentW[i] = iter->weight;
      iter = iter->next;
      i++;
    }
  } else {
    if (g->madj == NULL)
      return;
    for (j=0; j<g->V; j++)
      if (g->madj[index][j]!=0) {
        adjacentN[i] = j;
        adjacentW[i] = g->madj[index][j];
        i++;
      }
    }
  return;
}

int GRAPHdegree(Graph g, int index, int flag) {
  int i, count;
  node *iter;
  if (flag == 0) {
    if (g->ladj == NULL)
      return 0;
    count = 0;
    iter = g->ladj[index];
    while(iter != NULL) {
      count++;
      iter = iter->next;
    }
  } else {
      if (g->madj == NULL)
        return 0;
      count = 0;
      for (i=0; i<g->V; i++)
        if (g->madj[index][i])
          count++;
    }
  return count;
}
