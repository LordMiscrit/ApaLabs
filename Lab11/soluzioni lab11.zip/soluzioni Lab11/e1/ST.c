#include <stdlib.h>
#include <string.h>
#include "ST.h"

typedef struct htItem_ {
  char *id;
  int index;
} htItem;

struct ht {
  htItem *items;
  int N, M;
};

ST STinit(int maxN) {
  ST ht;
  int i;
  ht = malloc(sizeof(*ht));
  ht->N = 0;
  ht->M = maxN;
  ht->items = calloc(ht->M, sizeof(htItem) );
  for (i = 0; i < ht->M; i++)
    ht->items[i].index = -1;
  return ht;
}

int hash(char *str, int M) {
  int h = 0, base = 127;
  for ( ; *str != '\0'; str++)
    h = (base * h + *str) % M;
  return h;
}

int STcount(ST ht) {
  return ht->N;
}

int STempty(ST ht) {
  if (STcount(ht) == 0)
    return 1;
  else
    return 0;
}

void STinsert(ST ht, char *str, int index) {
  int i = hash(str, ht->M);
  while (ht->items[i].index != -1)
    i = (i+1) % ht->M;
  ht->items[i].id = str;
  ht->items[i].index = index;
  ht->N++;
}

int STsearch(ST ht, char *id) {
  int i = hash(id, ht->M);
  while (ht->items[i].index != -1)
    if (strcmp(id, ht->items[i].id) == 0)
      return ht->items[i].index;
    else
      i = (i+1) % ht->M;
  return -1;
}

void STfree(ST ht) {
  if (ht == NULL)
    return;
  free(ht->items);
  free(ht);
}
