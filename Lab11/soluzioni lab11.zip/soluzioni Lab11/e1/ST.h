#ifndef ST_H_INCLUDED
#define ST_H_INCLUDED

typedef struct ht *ST;

ST STinit(int maxN);
void STinsert(ST ht, char *str, int index);
int STsearch(ST ht, char *id);
void STfree(ST ht);
int STcount(ST ht);
int STempty(ST ht);

#endif // ST_H_INCLUDED
