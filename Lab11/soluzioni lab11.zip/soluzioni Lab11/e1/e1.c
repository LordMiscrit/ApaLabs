#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<ctype.h>

#include "ST.h"
#include "Graph.h"

#define MAXL 31

/*
 * NOTA: tutte le funzioni sono scritte per eseguire sia usando lAdj sia mAdj.
 * Basta passare il valore opportuno a "flag": 0 -> liste, 1 -> matrice
 * Nel men� non sono riportate le invocazioni su mAdj, per brevit�.
 */

typedef struct {
    char *name;
    char *subnet;
} node_t;

Graph read_file(FILE *in, ST *st_net, node_t **net, int *nV);

int main(int argc, char **argv) {
  char select[MAXL], *sel;
  int i, j, nV, stop = 0, index, *adjacentN, *adjacentW, extra, intra;
  Graph g = NULL;
  ST st_net = NULL;
  node_t *net = NULL;
  FILE *in;

  if (argc != 2) {
    printf("Use: %s <file_in>\n", argv[0]);
    exit(-1);
  }

  in = fopen(argv[1], "r");
  if (in == NULL)
    exit(-1);
  g = read_file(in, &st_net, &net, &nV);
  if (g == NULL || st_net == NULL || net == NULL) {
    exit(-1);
  }

  do {
        printf("\nQuale operazione vuoi eseguire?\n");
        printf("\tA: Visualizza numero e nome dei nodi\n");
        printf("\tB: Visualizza archi incidenti su un nodo\n");
        printf("\tC: Genera matrice di adiacenza\n");
        printf("\tD: Calcolo dei flussi\n");
        printf("\tZ: Esci\n");
        scanf("%s", select);
        for (sel=select; !isalpha(*sel); sel++);
        *sel = toupper(*sel);
        switch(*sel) {
            case 'A': {
                printf("Numero di vertici: %d\n", nV);
                for (i=0; i<nV; i++)
                  printf("\t%s\n", net[i].name);
            }
            break;
            case 'B': {
                printf("Quale nodo vuoi esaminare? [nome]\n");
                scanf("%s", select);
                index = STsearch(st_net, select);
                if (index >= 0) {
                  adjacentN = malloc(nV*sizeof(int));
                  adjacentW = malloc(nV*sizeof(int));
                  for (i=0; i<nV; i++) {
                    adjacentN[i] = -1;
                    adjacentW[i] = -1;
                  }
                  printf("Grado del nodo: %d\n", GRAPHdegree(g, index, 1));
                  GRAPHadjacent(g, adjacentN, adjacentW, index, 1);
                }
                printf("Nodi adiacenti: \n");
                for (i=0; i<nV; i++)
                  if (adjacentN[i]!=-1)
                    printf("\t%s", net[adjacentN[i]].name);
                printf("\n");
                free(adjacentN);
                free(adjacentW);
            }
            break;
            case 'C':
                if (!GRAPHlist2mat(g)) printf("Generazione avvenuta con successo!\n");
            break;
            case 'D': {
                intra = extra = 0;
                adjacentN = malloc(nV*sizeof(int));
                adjacentW = malloc(nV*sizeof(int));
                for (i=0; i<nV; i++) {
                  adjacentN[i] = -1;
                  adjacentW[i] = -1;
                }

                for (i=0; i<nV; i++) {

                  for (j=0; j<nV; j++) {
                    adjacentN[j] = -1;
                    adjacentW[j] = -1;
                  }
                  GRAPHadjacent(g, adjacentN, adjacentW, i, 0);

                  for (j=0; j<nV; j++)
                    if (adjacentN[j]!=-1) {
                      if (strcmp(net[i].subnet, net[adjacentN[j]].subnet)==0)
                        intra += adjacentW[j];
                      else
                        extra += adjacentW[j];
                    }
                }
                printf("Flusso intra-rete: %d\n", intra/2);
                printf("Flusso extra-rete: %d\n", extra/2);
                free(adjacentN);
                free(adjacentW);
            }
            break;
            case 'Z': {
                stop  = 1;
            }
            break;
            default:
                printf("Scelta non valida!\n");
        }
    } while(!stop);
  return 0;
}

Graph read_file(FILE *in, ST *st_net, node_t **net, int *nV) {
  int i, id1, id2;
  char c[MAXL], r[MAXL];

  fscanf(in, "%d", nV);
  Graph g = GRAPHinit(*nV);
  if (g == NULL)
    return NULL;

  *st_net = STinit(*nV);
  if (*st_net == NULL)
    return NULL;

  *net = malloc((*nV)*sizeof(node_t));
  if (*net == NULL)
  return NULL;

  for (i=0; i<*nV; i++) {
    fscanf(in, "%s %s", c, r);
    (*net)[i].name = strdup(c);
    (*net)[i].subnet = strdup(r);
    STinsert(*st_net, (*net)[i].name, i);
  }

  while(fscanf(in, "%s %s %d", c, r, &i) == 3) {
    id1 = STsearch(*st_net, c);
    id2 = STsearch(*st_net, r);
    if (id1 != id2 && id1 >= 0 && id2 >= 0)
      GRAPHinsertE(g, id1, id2, i, 0);
    }
  return g;
}
