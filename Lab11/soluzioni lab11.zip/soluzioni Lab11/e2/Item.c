#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Item.h"

struct item { char *name; int prio; };

Item ITEMnew(char *s, int p) {
  Item tmp = (Item) malloc(sizeof(struct item));
  tmp->name = strdup(s);
  tmp->prio = p;
  return tmp;
}

void ITEMshow(Item data) {
  printf("name = %s priority = %d  \n", data->name, data->prio);
}

int ITEMgreater(Item data1, Item data2) {
  Key k1 = KEYget(data1), k2 = KEYget(data2);
  if (KEYcompare(k1, k2) == 1)
    return 1;
  else
    return 0;
}

int ITEMless(Item data1, Item data2) {
  Key k1 = KEYget(data1), k2 = KEYget(data2);
  if (KEYcompare(k1, k2) == -1)
    return 1;
  else
    return 0;
}

int  KEYcompare(Key k1, Key k2) {
  if (k1 < k2)
    return -1;
  else if ( k1 == k2)
    return 0;
  else
    return 1;
}

Key KEYget(Item data) {
  return data->prio;
}
