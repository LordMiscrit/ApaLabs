#ifndef ITEM_H_DEFINED
#define ITEM_H_DEFINED

#include<string.h>
#include<stdlib.h>
#include<stdio.h>

typedef struct item* Item;
typedef int Key;

void ITEMshow(Item);
Item ITEMnew(char *, int);
int ITEMgreater(Item data1, Item data2);
int ITEMless(Item data1, Item data2);

int KEYcompare(Key k1, Key k2);
Key KEYget(Item data);

#endif
