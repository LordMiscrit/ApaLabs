#include <stdlib.h>
#include "Item.h"
#include "PQ.h"


struct pqueue { Item *array; int heapsize; int nMax; };

int LEFT(int i) {
  return i*2+1;
}

int RIGHT(int i) {
  return i*2+2;
}

int PARENT(int i) {
  return (i-1)/2;
}

PQ PQinit(){
  PQ pq;
  pq = malloc(sizeof(*pq));
  pq->array = (Item *)malloc(1*sizeof(Item));
  pq->heapsize = 0;
  pq->nMax = 1;
  return pq;
}


int PQempty(PQ pq) {
  return pq->heapsize == 0;
}

void PQinsert (PQ pq, Item item) {
  int i;
  if (pq->heapsize == pq->nMax) {
    pq->nMax *= 2;
    pq->array = realloc(pq->array, pq->nMax * sizeof(Item));
  }
  i  = pq->heapsize++;
  while( (i>=1) && (ITEMless(pq->array[PARENT(i)], item)) ) {
    pq->array[i] = pq->array[PARENT(i)];
    i = (i-1)/2;
  }
  pq->array[i] = item;
  return;
}

static void Swap(PQ pq, int n1, int n2) {
  Item temp;

  temp  = pq->array[n1];
  pq->array[n1] = pq->array[n2];
  pq->array[n2] = temp;
  return;
}

static void Heapify(PQ pq, int i) {
  int l, r, largest;
  l = LEFT(i);
  r = RIGHT(i);
  if ( (l < pq->heapsize) && (ITEMgreater(pq->array[l], pq->array[i])) )
    largest = l;
  else
    largest = i;
  if ( (r < pq->heapsize) && (ITEMgreater(pq->array[r], pq->array[largest])))
    largest = r;
  if (largest != i) {
    Swap(pq, i,largest);
	Heapify(pq, largest);
  }
  return;
}


Item PQget(PQ pq) {
  Item item;
  Swap (pq, 0,pq->heapsize-1);
  item = pq->array[pq->heapsize-1];
  pq->heapsize--;
  Heapify(pq, 0);
  return item;
}
