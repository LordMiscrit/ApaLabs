#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#define MAXC 31

int check(int *sol, int lungh, int k) {
  int j, tot=0;
  for (j=0; j<k; j++)
    tot += sol[j];
  if (tot==lungh)
    return 1;
  else
    return 0;
}

void disp_ripet(int pos, char *str, int *lunghezze, int *sol, int n, int k) {
  int i, j=0, lungh=strlen(str), out;
  if (pos >= k) {
    out = check(sol, lungh, k);
    if (out==1) {
      printf("Soluzione: \n");
      for (i=0; i<k; i++) {
        printf("%.*s ", sol[i], str+j);
        j += sol[i];
      }
      printf("\n");
    }
    return;
  }
  for (i = 0; i < n; i++) {
    if (pos + lunghezze[i] <= lungh) {
      sol[pos] = lunghezze[i];
      disp_ripet(pos+1, str, lunghezze, sol, n, k);
    }
  }
  return;
}

int main(void) {
  int N, i, k, *lunghezze, *sol, nstr, min=32;
  char str[MAXC];

  printf("Input N: ");
  scanf("%d", &N);
  lunghezze = malloc(N *sizeof(int));

  for (i=0; i<N; i++) {
    printf("lunghezze[%d]= ", i);
    scanf("%d", &lunghezze[i]);
    if (lunghezze[i] < min)
      min = lunghezze[i];
  }
  printf("Input stringa: ");
  scanf("%s", str);

  nstr = strlen(str)/min;

  for (k=1; k<=nstr; k++) {
    sol = malloc(k * sizeof(int));
    printf("\nDecomposizione con %d sottostringhe: \n", k);
    disp_ripet(0, str, lunghezze, sol, nstr, k);
    free(sol);
  }

  return 0;
}
