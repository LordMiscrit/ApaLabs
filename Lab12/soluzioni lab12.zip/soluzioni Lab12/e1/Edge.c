#include <stdio.h>
#include <stdlib.h>
#include "Edge.h"

Edge EDGEcreate(int v, int w) {
  Edge e;
  e.v = v;
  e.w = w;
  return e;
}

