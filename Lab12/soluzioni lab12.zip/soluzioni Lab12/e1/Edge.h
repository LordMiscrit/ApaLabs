
#ifndef EDGE_H_DEFINED
#define EDGE_H_DEFINED

typedef struct edge { int v; int w; } Edge;

Edge EDGEcreate(int v, int w);


#endif
