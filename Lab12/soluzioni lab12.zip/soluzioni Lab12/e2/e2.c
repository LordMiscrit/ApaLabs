#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include <string.h>

#define fn "amici.txt"

float check(int *sol, int N, int **U) {
  int i, j, TOT = 0, max = -1;
  for (i=0; i<N; i++) {
	if (sol[i] > max)
      max = sol[i];
    for (j=i+1; j<N; j++)  // per tutte le coppie <i,j> in un'auto k
      if (sol[i] == sol[j])
        TOT += U[i][j];
  }
  // Usa max per dividere solo per il numero di auto effettivamente utilizzate, anzich� per K
  return TOT / (float) (max+1);
}

int gen_part(int *sol, int *occupa, int N, int K, int M, int U, int pos, int **mat) {
  int i;
  if (pos >= N) {
    float u = check(sol, N, mat);
    if (u > U) {
      printf("Trovata soluzione %.3f > %d\n", u, U);
      for(i=0;i<N;i++) printf("%d ", sol[i]);
      return 1;
    }
    return 0;
  }
  for(i=0;i<K;i++) {
    // questa condizione di pruning permette di rompere un caso semplice di simmetria delle soluzioni.
    // generate tutte le possibili partizioni in cui l'amico 0 � fisso in un'auto, tutte le altre assegnazioni
    // sono una variante simmetrica di quelle gi� considerate (amico 0 sempre in auto0, o in auto1, e cos� via...)
    if (pos == 0 && i > 0) break;
    // Riempi l'i-esimo veicolo se non � gi� pieno
    if (occupa[i] < M) {
      occupa[i]++;
      sol[pos] = i;
      if (gen_part(sol, occupa, N, K, M, U, pos+1, mat))
        return 1;
      occupa[i]--;
    }
  }
  return 0;
}

int main() {
  int N, K, M, U, i, j, **mat, *sol, *occupa;
  FILE *in = fopen(fn, "r");
  fscanf(in, "%d %d %d %d", &N, &K, &M, &U);
  mat = calloc(N, sizeof(int*));
  for (i=0; i<N; i++) {
    mat[i] = calloc(N, sizeof(int));
    for (j=0; j<N; j++)
      fscanf(in, "%d", &mat[i][j]);
  }

  sol = calloc(N, sizeof(int));
  occupa = calloc(K, sizeof(int));

  gen_part(sol, occupa, N, K, M, U, 0, mat);

  return 0;
}
