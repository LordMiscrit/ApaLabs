#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include <string.h>

#define fn "amici.txt"
#define DBG 0

float check(int *sol, int N, int **U, int B) {
  int i, j, TOT = 0;
  for (i=0; i<N; i++) {
    for (j=i+1; j<N; j++) // per tutte le coppie <i,j> in un'auto k
      if (sol[i] == sol[j])
        TOT += U[i][j];
  }
  return TOT / (float) (B);
}

void genera(int *sol, int *occupa, int N, int K, int M, int pos, int B, int **mat, int *bsol, float *best) {
  int i;
  float u;
  if (pos >= N) {
    u = check(sol, N, mat, B);
#if DBG
    printf("Sol attuale: ");
    for(i=0;i<N;i++) printf("%d", sol[i]); printf(" :: VAL = %.3f\n", u);
#endif
    if (u > *best) {
      *best = u;
      memcpy(bsol, sol, N*sizeof(int));
    }
    return;
  }
  for (i=0; i<B; i++)
    if (occupa[i] < M) {
      occupa[i]++;
      sol[pos] = i;
      genera(sol, occupa, N, K, M, pos+1, B, mat, bsol, best);
      occupa[i]--;
    }
  if (B < K) {
    sol[pos] = B;
    occupa[B]++;
    genera(sol, occupa, N, K, M, pos+1, B+1, mat, bsol, best);
    occupa[B]--;
  }
}

int main() {
  int N, K, M, i, j, **mat, *sol, *bsol, *occupa;
  FILE *in = fopen(fn, "r");
  float best;

  fscanf(in, "%d %d %d", &N, &K, &M);
  mat = calloc(N, sizeof(int*));
  for (i=0; i<N; i++) {
    mat[i] = calloc(N, sizeof(int));
    for (j=0; j<N; j++)
      fscanf(in, "%d", &mat[i][j]);
  }
  sol = calloc(N, sizeof(int));
  bsol = calloc(N, sizeof(int));
  occupa = calloc(K, sizeof(int));
  best = -FLT_MAX ;

  genera(sol, occupa, N, K, M, 0, 0, mat, bsol, &best);

  printf("Best = %.3f\n", best);
  for (i=0; i<N; i++)
    printf("%d ", bsol[i]);
  printf("\n");
  return 0;
}
